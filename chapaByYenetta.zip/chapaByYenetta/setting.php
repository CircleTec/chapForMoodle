// payment/gateway/chapa/settings.php
<?php
defined('MOODLE_INTERNAL') || die();

if ($ADMIN->fulltree) {
    $settings->add(new admin_setting_configtext(
        'paygw_chapa/secret_key',
        get_string('secret_key', 'paygw_chapa'),
        get_string('secret_key_help', 'paygw_chapa'),
        '',
        PARAM_TEXT
    ));

    $settings->add(new admin_setting_configtext(
        'paygw_chapa/public_key',
        get_string('public_key', 'paygw_chapa'),
        get_string('public_key_help', 'paygw_chapa'),
        '',
        PARAM_TEXT
    ));
    
    $settings->add(new admin_setting_configtext(
        'paygw_chapa/webhook_secret',
        get_string('webhook_secret', 'paygw_chapa'),
        get_string('webhook_secret_help', 'paygw_chapa'),
        '',
        PARAM_TEXT
    ));
}