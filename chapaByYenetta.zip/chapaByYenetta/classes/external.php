// payment/gateway/chapa/classes/external.php
<?php
namespace paygw_chapa\external;

use external_api;
use external_function_parameters;
use external_value;

class get_config extends external_api {
    public static function execute($component, $paymentarea, $itemid): array {
        $config = new \stdClass();
        $config->publickey = get_config('paygw_chapa', 'public_key');
        return [
            'publickey' => $config->publickey,
        ];
    }
}