// payment/gateway/chapa/classes/gateway.php
<?php
namespace paygw_chapa;

use core_payment\gateway;
use core_payment\exception;

class gateway implements gateway {
    public static function get_supported_currencies(): array {
        return ['ETB' => 'Ethiopian Birr'];
    }

    public static function get_configuration_form_elements($form, $config) {
        $form->addElement('text', 'secret_key', get_string('secret_key', 'paygw_chapa'));
        $form->setType('secret_key', PARAM_TEXT);
        $form->addElement('text', 'public_key', get_string('public_key', 'paygw_chapa'));
        $form->setType('public_key', PARAM_TEXT);
        
        $form->addElement('text', 'webhook_secret', get_string('webhook_secret', 'paygw_chapa'));
        $form->setType('webhook_secret', PARAM_TEXT);
    }

    public static function validate_config($data, $files, $errors): array {
        if (empty($data['secret_key'])) {
            $errors['secret_key'] = get_string('secret_key_required', 'paygw_chapa');
        }
        if (empty($data['public_key'])) {
            $errors['public_key'] = get_string('public_key_required', 'paygw_chapa');
        }
        return $errors;
    }
}