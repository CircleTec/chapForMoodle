<?php
namespace paygw_chapa;

defined('MOODLE_INTERNAL') || die();

class payment {
    public function create_payment($config, $order) {
        global $USER, $CFG;

        $tx_ref = 'MDL-' . time() . '-' . $USER->id . '-' . $order->get_id();
        
        $data = [
            'amount' => $order->get_amount(),
            'currency' => $order->get_currency(),
            'tx_ref' => $tx_ref,
            'email' => $USER->email,
            'first_name' => $USER->firstname,
            'last_name' => $USER->lastname,
            'callback_url' => $CFG->wwwroot . '/payment/gateway/chapa/callback.php',
            'return_url' => $order->get_return_url(),
        ];

        $response = $this->call_chapa_api('initialize', $data, $config->secret_key);
        
        if (!empty($response->data->checkout_url)) {
            $record = new \stdClass();
            $record->orderid = $order->get_id();
            $record->tx_ref = $tx_ref;
            $record->status = 'pending';
            $record->timecreated = time();
            $record->timemodified = time();
            
            global $DB;
            $DB->insert_record('paygw_chapa', $record);
            
            return $response->data->checkout_url;
        }
        
        throw new \moodle_exception('errorinitiatingpayment', 'paygw_chapa');
    }

    public function verify_payment($tx_ref, $config) {
        $response = $this->call_chapa_api('verify/' . $tx_ref, null, $config->secret_key);
        
        if (empty($response)) {
            throw new \moodle_exception('invalidresponse', 'paygw_chapa');
        }
        
        return $response;
    }

    private function call_chapa_api($endpoint, $data, $secret_key) {
        $base_url = 'https://api.chapa.co/v1/transaction/';
        
        $ch = curl_init($base_url . $endpoint);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $secret_key,
            'Content-Type: application/json'
        ]);
        
        if ($data) {
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        }
        
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        
        $response = curl_exec($ch);
        curl_close($ch);
        
        return json_decode($response);
    }
}
