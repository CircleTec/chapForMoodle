<?php
require_once(__DIR__ . '/../../../config.php');
require_once($CFG->dirroot . '/payment/gateway/chapa/lib.php');

@error_reporting(0);
@ini_set('display_errors', '0');

$payload = file_get_contents('php://input');
$data = json_decode($payload);
$signature = $_SERVER['HTTP_CHAPA_SIGNATURE'] ?? '';

function verify_webhook_signature($payload, $signature) {
    $webhook_secret = get_config('paygw_chapa', 'webhook_secret');
    $expected = hash_hmac('sha256', $payload, $webhook_secret);
    return hash_equals($expected, $signature);
}

if (!verify_webhook_signature($payload, $signature)) {
    http_response_code(401);
    die('Invalid signature');
}

if (!empty($data->tx_ref)) {
    $transaction = $DB->get_record('paygw_chapa', ['tx_ref' => $data->tx_ref]);
    if (!$transaction) {
        http_response_code(404);
        die('Transaction not found');
    }

    switch ($data->event) {
        case 'charge.success':
            if ($transaction->status !== 'success') {
                $transaction->status = 'success';
                $transaction->timemodified = time();
                $DB->update_record('paygw_chapa', $transaction);

                try {
                    \core_payment\helper::deliver_order($transaction->orderid, 'paygw_chapa', $transaction->id);
                } catch (Exception $e) {
                    debugging('Failed to deliver order: ' . $e->getMessage(), DEBUG_DEVELOPER);
                }
            }
            break;

        case 'charge.failed':
            $transaction->status = 'failed';
            $transaction->timemodified = time();
            $DB->update_record('paygw_chapa', $transaction);
            break;

        case 'charge.refunded':
            $transaction->status = 'refunded';
            $transaction->timemodified = time();
            $DB->update_record('paygw_chapa', $transaction);
            break;
    }

    $log = new stdClass();
    $log->transaction_id = $transaction->id;
    $log->event = $data->event;
    $log->payload = $payload;
    $log->timecreated = time();
    $DB->insert_record('paygw_chapa_webhook_logs', $log);

    http_response_code(200);
    die('Webhook processed');
}

http_response_code(400);
die('Invalid webhook data');