// payment/gateway/chapa/lang/en/paygw_chapa.php
<?php
$string['pluginname'] = 'Chapa';
$string['pluginname_desc'] = 'The Chapa plugin allows you to receive payments via Chapa.';
$string['secret_key'] = 'Secret Key';
$string['secret_key_help'] = 'The secret key you received from Chapa';
$string['public_key'] = 'Public Key';
$string['public_key_help'] = 'The public key you received from Chapa';
$string['webhook_secret'] = 'Webhook Secret';
$string['webhook_secret_help'] = 'The webhook secret for verifying Chapa callbacks';
$string['payment_successful'] = 'Payment was successful';
$string['payment_failed'] = 'Payment failed';
$string['invalidresponse'] = 'Invalid response from Chapa';
$string['secret_key_required'] = 'Secret key is required';
$string['public_key_required'] = 'Public key is required';