<?php
require_once(__DIR__ . '/../../../config.php');
require_once($CFG->dirroot . '/payment/gateway/chapa/lib.php');

$tx_ref = required_param('tx_ref', PARAM_TEXT);

$transaction = $DB->get_record('paygw_chapa', ['tx_ref' => $tx_ref], '*', MUST_EXIST);

$payment = new \paygw_chapa\payment();
$config = (object) [
    'secret_key' => get_config('paygw_chapa', 'secret_key')
];

try {
    $response = $payment->verify_payment($tx_ref, $config);
    
    if ($response->status === 'success') {
        $transaction->status = 'success';
        $transaction->timemodified = time();
        $DB->update_record('paygw_chapa', $transaction);

        $payable = $DB->get_record('payment_payables', ['id' => $transaction->orderid], '*', MUST_EXIST);
        \core_payment\helper::deliver_order($transaction->orderid, 'paygw_chapa', $transaction->id);

        redirect(
            new moodle_url($payable->successurl),
            get_string('payment_successful', 'paygw_chapa'),
            null,
            \core\output\notification::NOTIFY_SUCCESS
        );
    } else {
        throw new moodle_exception('payment_failed', 'paygw_chapa');
    }
} catch (Exception $e) {
    $transaction->status = 'failed';
    $transaction->timemodified = time();
    $DB->update_record('paygw_chapa', $transaction);

    redirect(
        new moodle_url('/'),
        get_string('payment_failed', 'paygw_chapa'),
        null,
        \core\output\notification::NOTIFY_ERROR
    );
}
